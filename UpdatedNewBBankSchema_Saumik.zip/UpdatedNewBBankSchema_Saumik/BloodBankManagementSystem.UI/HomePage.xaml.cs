﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace BloodBankManagementSystem.UI
{
    /// <summary>
    /// Interaction logic for HomePage.xaml
    /// </summary>
    public partial class HomePage : Window
    {
        public HomePage()
        {
            InitializeComponent();
        }

        private void MenuBBDetails_Click(object sender, RoutedEventArgs e)
        {
            BloodBank bloodBank = new BloodBank();
            bloodBank.ShowDialog();
        }

        private void MenuModBBDetails_Click(object sender, RoutedEventArgs e)
        {
            BloodBankModify bloodBankModify = new BloodBankModify();
            bloodBankModify.ShowDialog();
        }

        private void MenuViewBBDetails_Click(object sender, RoutedEventArgs e)
        {
            ViewBloodBankDetails viewBloodBank = new ViewBloodBankDetails();
            viewBloodBank.ShowDialog();
        }

        private void MenuHDetails_Click(object sender, RoutedEventArgs e)
        {
            HospitalManager hospitalManager = new HospitalManager();
            hospitalManager.ShowDialog();
        }

        private void MenuModHDetails_Click(object sender, RoutedEventArgs e)
        {
            HospitalModify hospitalModify = new HospitalModify();
            hospitalModify.ShowDialog();
        }

        private void MenuViewHDetails_Click(object sender, RoutedEventArgs e)
        {
            ViewHospitalDetails viewHospitalDetails = new ViewHospitalDetails();
            viewHospitalDetails.ShowDialog();
        }
    }
}
