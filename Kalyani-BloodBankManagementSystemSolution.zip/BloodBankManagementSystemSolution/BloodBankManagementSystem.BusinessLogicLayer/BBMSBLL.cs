﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BloodBankManagementSystem.Entity;
using BloodBankManagementSystem.DataAccessLayer;
using System.Data;

namespace BloodBankManagementSystem.BusinessLogicLayer
{
    public class BBMSBLL
    {
        public bool ArrangeCampBLL(BBMSEntity arrange)
        {
            bool arrangeCamp = false;
            try
            {
                BBMSDAL bBMSDAL = new BBMSDAL();
                arrangeCamp = bBMSDAL.ArrangeCampDAL(arrange);
            }
            catch
            {
                throw;
            }

            return arrangeCamp;
        }

        public DataTable ViewCampDetailsBLL()
        {
            try
            {
                BBMSDAL bBMSDAL = new BBMSDAL();
                return bBMSDAL.ViewCampDetailsDAL();
            }
            catch
            {
                throw;
            }
        }

        public bool ModifyCampBLL(BBMSEntity modify)
        {
            try
            {
                BBMSDAL bd = new BBMSDAL();
                return bd.ModifyCampDAL(modify);
            }
            catch
            {
                throw;
            }
        }

        public bool DeleteCampBLL(int bloodDonationCampID)
        {
            try
            {
                BBMSDAL bd = new BBMSDAL();
                return bd.DeleteCampDAL(bloodDonationCampID);
            }
            catch
            {
                throw;
            }
        }

        public BBMSEntity SearchCampBLL(int bloodDonationCampID)
        {
            try
            {
                BBMSDAL bd = new BBMSDAL();
                return bd.SearchCampDAL(bloodDonationCampID);
            }
            catch
            {
                throw;
            }
        }
    }
}
