﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using BloodBankManagementSystem.BusinessLogicLayer;

namespace BloodBankManagementSystem.PresentationLayer
{
    /// <summary>
    /// Interaction logic for ViewCampDetails.xaml
    /// </summary>
    public partial class ViewCampDetails : Window
    {
        public ViewCampDetails()
        {
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            BBMSBLL viewCamp = new BBMSBLL();
            DataTable dt = viewCamp.ViewCampDetailsBLL();
            if (dt != null)
            {
                dgViewCampDetails.ItemsSource = dt.DefaultView;
            }
            else
            {
                MessageBox.Show("Table is empty");
            }

        }
    }
}
