﻿using BloodBankManagementSystem.Entity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using BloodBankManagementSystem.BusinessLogicLayer;

namespace BloodBankManagementSystem.PresentationLayer
{
    /// <summary>
    /// Interaction logic for ArrangeCamp.xaml
    /// </summary>
    public partial class ArrangeCamp : Window
    {
        public ArrangeCamp()
        {
            InitializeComponent();
        }

        private void txtBloodDonationCampId_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void btnArrange_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                BBMSEntity arrange = new BBMSEntity
                {
                    BloodDonationCampId=Convert.ToInt32(txtBloodDonationCampId.Text),
                    CampName=txtCampName.Text,
                    Address=txtAddress.Text,
                    City=txtCity.Text,
                    BloodBankId=txtBloodBankId.Text,
                    CampStartDate=Convert.ToDateTime(txtCampStartDate.Text),
                    CampEndDate=Convert.ToDateTime(txtCampEndDate.Text)
                };


                BBMSBLL bBMSBLL = new BBMSBLL();
                bool b = bBMSBLL.ArrangeCampBLL(arrange);
                if (b)
                {
                    MessageBox.Show(" Blood Donation Camp Arranged Successfully");


                }
                else
                {
                    MessageBox.Show("Details Not Added");
                }

            }
            catch 
            {
                throw;
            }
        }
    }
}
