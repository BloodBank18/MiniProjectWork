﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BloodBankManagementSystem.Entity;
using BloodBankManagementSystem.DataAccessLayer;
using System.Data;
using System.Text.RegularExpressions;


namespace BloodBankManagementSystem.BusinessLogicLayer
{
    public class BBMSBLL
    {
        BBMSDAL bbDL = new BBMSDAL();
        StringBuilder sb = new StringBuilder();

        public bool validateCampIdArrange(string BloodDonationCampId)
        {
            bool valid = true;
            if (bbDL.VerifyBloodDonationCampID(BloodDonationCampId) == 1)
            {
                valid = false;
                sb.Append(Environment.NewLine + "\nBlood Donation Camp ID already exists");
            }
            if (valid == false)
                throw new SystemException(sb.ToString());
            return valid;
        }
        public bool validateCampIdModify(string BloodDonationCampId)
        {
            bool valid = true;
            if (bbDL.VerifyBloodDonationCampID(BloodDonationCampId) == 0)
            {
                valid = false;
                sb.Append(Environment.NewLine + "\nBlood Donation Camp ID not found");
            }
            if (valid == false)
                throw new SystemException(sb.ToString());
            return valid;
        }

        public bool validateCampIdDelete(string BloodDonationCampId)
        {
            Regex r1 = new Regex("^[D]{1}[C]{1}[0-9]{5}$");
            bool valid = true;
            if (BloodDonationCampId == "")
            {
                valid = false;
                sb.Append(Environment.NewLine + "\nBlood Donation Camp ID cannot be empty");
            }
            else if (!r1.IsMatch(BloodDonationCampId))
            {
                valid = false;
                sb.Append(Environment.NewLine + "\nBlood Donation Camp ID is not valid");
            }
            if (valid == false)
                throw new SystemException(sb.ToString());
            return valid;
        }


        public bool ValidateBloodDonationCampData(string BloodDonationCampId, string CampName, string Address, string City, string BloodBankId, string CampStartDate, string CampEndDate)
        {
            Regex r1 = new Regex("^[D]{1}[C]{1}[0-9]{5}$");
            Regex r2 = new Regex("^[B]{1}[B]{1}[0-9]{5}$");
           
            bool valid = true;
            if (BloodDonationCampId == "")
            {
                valid = false;
                sb.Append(Environment.NewLine + "\nBlood Donation Camp ID cannot be empty");
            }
            else if (!r1.IsMatch(BloodDonationCampId))
            {
                valid = false;
                sb.Append(Environment.NewLine + "\nBlood Donation Camp ID is not valid");
            }

            if (CampName == "")
            {
                valid = false;
                sb.Append(Environment.NewLine + "\nBlood Donation Camp Name cannot be empty");
            }
            if (BloodBankId == "")
            {
                valid = false;
                sb.Append(Environment.NewLine + "\nBlood Donation Last Name cannot be empty");
            }
            else if (!r2.IsMatch(BloodBankId))
            {
                valid = false;
                sb.Append(Environment.NewLine + "\nBlood Donation Camp ID is not in proper format");
            }
            if (Address == "")
            {
                valid = false;
                sb.Append(Environment.NewLine + "\nAddress cannot be empty");
            }
            if (City == "")
            {
                valid = false;
                sb.Append(Environment.NewLine + "\nCity cannot be empty");
            }
            if (Convert.ToDateTime(CampStartDate) > Convert.ToDateTime(CampEndDate))
            {
                valid = false;
                sb.Append(Environment.NewLine + "\nCamp start date cannot be greater than Camp end date");
            }
            if (valid == false)
                throw new SystemException(sb.ToString());
            return valid;
        }

        public bool ArrangeCampBLL(BBMSEntity arrange)
        {
            bool arrangeCamp = false;
            try
            {
                BBMSDAL bBMSDAL = new BBMSDAL();
                arrangeCamp = bBMSDAL.ArrangeCampDAL(arrange);
            }
            catch
            {
                throw;
            }

            return arrangeCamp;
        }

        public DataTable ViewCampDetailsBLL()
        {
            try
            {
                BBMSDAL bBMSDAL = new BBMSDAL();
                return bBMSDAL.ViewCampDetailsDAL();
            }
            catch
            {
                throw;
            }
        }

        public bool ModifyCampBLL(BBMSEntity modify)
        {
            try
            {
                BBMSDAL bd = new BBMSDAL();
                return bd.ModifyCampDAL(modify);
            }
            catch
            {
                throw;
            }
        }

        public bool DeleteCampBLL(int bloodDonationCampID)
        {
            try
            {
                BBMSDAL bd = new BBMSDAL();
                return bd.DeleteCampDAL(bloodDonationCampID);
            }
            catch
            {
                throw;
            }
        }

        public BBMSEntity SearchCampBLL(string bloodDonationCampID)
        {
            try
            {
                BBMSDAL bd = new BBMSDAL();
                return bd.SearchCampDAL(bloodDonationCampID);
            }
            catch
            {
                throw;
            }
        }
    }
}
