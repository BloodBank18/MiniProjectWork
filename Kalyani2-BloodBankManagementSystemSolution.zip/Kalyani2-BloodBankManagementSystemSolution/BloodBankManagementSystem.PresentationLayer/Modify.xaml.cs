﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using BloodBankManagementSystem.BusinessLogicLayer;
using BloodBankManagementSystem.Entity;

namespace BloodBankManagementSystem.PresentationLayer
{
    /// <summary>
    /// Interaction logic for Modify.xaml
    /// </summary>
    public partial class Modify : Window
    {
        public Modify()
        {
            InitializeComponent();
        }

        private void btnUpdateCampDetails_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                  BBMSBLL bb = new BBMSBLL();
                if (bb.ValidateBloodDonationCampData(txtBloodDonationCampId.Text, txtCampName.Text, txtAddress.Text, txtCity.Text, txtBloodBankId.Text, txtCampStartDate.Text, txtCampEndDate.Text))
                {
                    if (bb.validateCampIdModify(txtBloodDonationCampId.Text))
                    {
                        BBMSEntity b = new BBMSEntity
                        {
                            BloodDonationCampId = txtBloodDonationCampId.Text,
                            CampName = txtCampName.Text,
                            Address = txtAddress.Text,
                            City = txtCity.Text,
                            CampStartDate = Convert.ToDateTime(txtCampStartDate.Text),
                            CampEndDate = Convert.ToDateTime(txtCampEndDate.Text)
                        };

                        if (bb.ModifyCampBLL(b))
                        {
                            txtBloodDonationCampId.IsEnabled = true;
                            gbModify.Visibility = Visibility.Hidden;
                            MessageBox.Show("Blood Donation Camp Info Saved.");
                        }
                    }
                }
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnDeleteCampDetails_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                BBMSBLL bd = new BBMSBLL();
                if (bd.validateCampIdDelete(txtBloodDonationCampId.Text))
                {
                    int bloodDonationCampId = int.Parse(txtBloodDonationCampId.Text);
                    BBMSBLL bb = new BBMSBLL();
                    if (bb.DeleteCampBLL(bloodDonationCampId))
                    {
                        gbModify.Visibility = Visibility.Hidden;
                        txtBloodDonationCampId.IsEnabled = true;
                        MessageBox.Show("Blood Donation Camp Id " + bloodDonationCampId + " was deleted.");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnsearchCamp_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                    BBMSBLL bb = new BBMSBLL();
                    BBMSEntity b = bb.SearchCampBLL(txtBloodDonationCampId.Text);
                    if (b != null)
                    {
                        txtCampName.Text = b.CampName;
                        txtAddress.Text = b.Address;
                        txtCity.Text = b.City;
                        txtBloodBankId.Text = b.BloodBankId.ToString();
                        txtCampStartDate.Text = b.CampStartDate.ToString();
                        txtCampEndDate.Text = b.CampEndDate.ToString();
                        gbModify.Visibility = Visibility.Visible;
                    txtBloodDonationCampId.IsEnabled = false;
                    }
                    else
                    {
                        gbModify.Visibility = Visibility.Hidden;
                        MessageBox.Show
                            (string.Format("Blood Donation camp with id {0} does not exists.", txtBloodDonationCampId.Text));
                    }
                
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
