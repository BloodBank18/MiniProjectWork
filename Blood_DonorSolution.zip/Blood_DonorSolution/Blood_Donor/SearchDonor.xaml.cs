﻿using BusinessLogicLayer;
using EntityLayer;
using Exceptions;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Blood_Donor
{
    /// <summary>
    /// Interaction logic for SearchDonor.xaml
    /// </summary>
    public partial class SearchDonor : Window
    {
        public SearchDonor()
        {
            InitializeComponent();
        }

        private void btnUpdate_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                DonorEntities de = new DonorEntities
                {
                    BloodDonorID = txtDID.Text,
                    FirstName = txtFName.Text,
                    LastName = txtLName.Text,
                    Address = txtAdd.Text,
                    City = txtCity.Text,
                    Mobile = txtMob.Text,
                    BloodGroup = Convert.ToInt32(cmbBG.SelectedValue)
                };
                DonorBL db = new DonorBL();
                if (db.EditDonor(de))
                {
                    gb1.Visibility = Visibility.Hidden;
                    MessageBox.Show("Donor Info Saved.", "Blood Bank Management System");
                }
            }
            catch (BloodDonorException ex)
            {
                MessageBox.Show(ex.Message, "Blood Bank Management System");
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message, "Blood Bank Management System");
            }
        }

        private void btnSearch_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                DonorBL db = new DonorBL();
                DonorEntities de = db.Search(txtDID.Text);
                if (de != null)
                {
                    txtFName.Text = de.FirstName;
                    txtLName.Text = de.LastName;
                    txtAdd.Text = de.Address;
                    txtCity .Text = de.City;
                    txtMob.Text = de.Mobile;
                    cmbBG.SelectedValue = de.BloodGroup.ToString();
                    gb1.Visibility = Visibility.Visible;
                }
                else
                {
                    gb1.Visibility = Visibility.Hidden;
                    MessageBox.Show
                        (string.Format("Donor with id {0} does not exists.", txtDID.Text),
                        "Blood Bank Management System");
                }
            }
            catch (BloodDonorException ex)
            {
                MessageBox.Show(ex.Message, "Blood Bank Management System");
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message, "Blood Bank Management System");
            }
        }

        private void btnDelete_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                string did = txtDID.Text;
                DonorBL pb = new DonorBL();
                if (pb.DeleteDonor(did))
                {
                    gb1.Visibility = Visibility.Hidden;
                    MessageBox.Show("Donor Id " + did + " was deleted.");
                }
            }
            catch (BloodDonorException ex)
            {
                MessageBox.Show(ex.Message, "Blood Bank Management System");
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message, "Blood Bank Management System");
            }
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            try
            {
                DonorBL db = new DonorBL();
                DataTable dt = db.GetCategories();
                if (dt != null)
                {
                    cmbBG.ItemsSource = dt.DefaultView;
                    cmbBG.DisplayMemberPath = "BG";
                    cmbBG.SelectedValuePath = "BGId";
                }
                else
                {
                    MessageBox.Show("Table is empty", "Blood Bank Management System");
                }
            }
            catch (BloodDonorException ex)
            {
                MessageBox.Show(ex.Message, "Blood Bank Management System");
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message, "Blood Bank Management System");
            }
        }
    }
}
