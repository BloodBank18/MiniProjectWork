﻿using DataAccessLayer;
using EntityLayer;
using Exceptions;
using System;
using System.Data;
using System.Data.SqlClient;
using System.Text;
using System.Text.RegularExpressions;

namespace BusinessLogicLayer
{
    public class DonorBL
    {
        public bool AddDonor(DonorEntities de)
        {
            try
            {

                BloodDonorDAL pdl = new BloodDonorDAL();
                return pdl.AddDonor(de);
                

            }
            catch (BloodDonorException)
            {

                throw;
            }
        }

        public bool ValidateBloodDonorData(string BloodDonorID, string FirstName, string LastName,string Address, string City, string Mobile)
        {


            Regex r = new Regex("^[7-9]{1}[0-9]{9}$");

            Regex r2 = new Regex("^[B]{1}[D]{1}[0-9]{5}$");

            BloodDonorDAL bbDL = new BloodDonorDAL();

            StringBuilder sb = new StringBuilder();

            bool valid = true;
            if (BloodDonorID == "")
            {
                valid = false;
                sb.Append(Environment.NewLine + "\nDonor ID cannot be empty");
            }
            else if (!r2.IsMatch(BloodDonorID))
            {
                valid = false;
                sb.Append(Environment.NewLine + "\nDonor ID is not in proper format");
            }
            else if (bbDL.VerifyBloodDonorID(BloodDonorID)==1)
            {
                valid = false;
                sb.Append(Environment.NewLine + "\nDonor ID already exists");
            }

            if (FirstName == "")
            {
                valid = false;
                sb.Append(Environment.NewLine + "\nDonor First Name cannot be empty");
            }
            if (LastName == "")
            {
                valid = false;
                sb.Append(Environment.NewLine + "\nDonor Last Name cannot be empty");
            }
            if (Address == "")
            {
                valid = false;
                sb.Append(Environment.NewLine + "\nAddress cannot be empty");
            }
            if (City == "")
            {
                valid = false;
                sb.Append(Environment.NewLine + "\nCity cannot be empty");
            }
            if (!r.IsMatch(Mobile))
            {
                valid = false;
                sb.Append(Environment.NewLine + "\nPhone number is not in proper format");
            }
            

            if (valid == false)
                throw new BloodDonorException(sb.ToString());
            return valid;
        }

        public bool EditDonor(DonorEntities pobj)
        {
            BloodDonorDAL pd = new BloodDonorDAL();
            try
            {
                    return pd.UpdateDonor(pobj);
            }
            catch (BloodDonorException)
            {
                throw;
            }
            catch (SqlException)
            {
                throw;
            }
            catch (SystemException)
            {
                throw;
            }
        }

        public bool DeleteDonor(string donorId)
        {
            try
            {
                BloodDonorDAL pd = new BloodDonorDAL();
                return pd.DeleteDonor(donorId);
            }
            catch (BloodDonorException)
            {
                throw;
            }
            catch (SqlException)
            {
                throw;
            }
            catch (SystemException)
            {
                throw;
            }
        }

        public DonorEntities Search(string donorId)
        {
            try
            {
                BloodDonorDAL pd = new BloodDonorDAL();
                return pd.Search(donorId);
            }
            catch (BloodDonorException)
            {
                throw;
            }
            catch (SqlException)
            {
                throw;
            }
            catch (SystemException)
            {
                throw;
            }
        }

        public DataTable Display()
        {
            try
            {
                BloodDonorDAL pd = new BloodDonorDAL();
                return pd.Display();
            }
            catch (BloodDonorException)
            {
                throw;
            }
            catch (SqlException)
            {
                throw;
            }
            catch (SystemException)
            {
                throw;
            }
        }

        public DataTable GetCategories()
        {
            try
            {
                BloodDonorDAL pd = new BloodDonorDAL();
                return pd.GetCategories();
            }
            catch (BloodDonorException)
            {
                throw;
            }
            catch (SqlException)
            {
                throw;
            }
            catch (SystemException)
            {
                throw;
            }
        }
    }
}
