﻿using System;
using System.Runtime.Serialization;

namespace Exceptions
{
    [Serializable]
    public class BloodDonorException : Exception
    {
        public BloodDonorException()
        {
        }

        public BloodDonorException(string message) : base(message)
        {
        }

        public BloodDonorException(string message, Exception innerException) : base(message, innerException)
        {
        }

        protected BloodDonorException(SerializationInfo info, StreamingContext context) : base(info, context)
        {
        }
    }
}