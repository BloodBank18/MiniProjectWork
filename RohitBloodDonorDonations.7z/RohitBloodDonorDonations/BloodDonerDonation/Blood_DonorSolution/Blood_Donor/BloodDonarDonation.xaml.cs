﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Exceptions;
using BusinessLogicLayer;
using System.Data;
using BusinessLogicLayer;
using EntityLayer;
using Exceptions;

namespace Blood_Donor
{
    /// <summary>
    /// Interaction logic for BloodDonarDonation.xaml
    /// </summary>
    public partial class BloodDonarDonation : Window
    {


public BloodDonarDonation()
        {





            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {

          

        }

        private void textBox3_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void button_Click(object sender, RoutedEventArgs e)
        {

            try
            {
                DonorBL b = new DonorBL();
                
                if (b.ValidateBloodDonationDetails(txtBloodDonorId.Text,dateChoose.Text,txtnoofbottle.Text,textweight.Text,txtHB.Text))
                {


                    BloodDonorDonation p = new BloodDonorDonation
                    {
                        BloodDonorID = txtBloodDonorId.Text,
                        BloodDonationDate = DateTime.Parse(dateChoose.Text),
                        NumberOfBottles = int.Parse(txtnoofbottle.Text),
                        Weight = int.Parse(textweight.Text),
                        HBCount = decimal.Parse(txtHB.Text)
                    };
                    DonorBL pb = new DonorBL();
                    int pid = pb.AddDonation(p);
                    BloodDonationLabel.Content = pid.ToString();

                   


                    MessageBox.Show(string.Format("New donation added.\ndonation id Id:{0}", pid),
                        "BBMS");
                    clearall();
                   }

                }
            catch (BloodDonorException ex)
            {
                MessageBox.Show(ex.Message, "BBMS");
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message, "BBMS");
            }

            



        }

        public void clearall()
        {
           BloodDonationLabel.Content = null;
            txtBloodDonorId.Text = null;
            txtHB.Text = null;
            txtnoofbottle.Text = null;
            textweight.Text = null;




        }

        private void button1_Click(object sender, RoutedEventArgs e)
        {
           DonationDetails w = new DonationDetails();
            w.Show();
           




        }
    }
}
