create schema BBank
create table BBank.BloodBank(BloodBankId int primary key, BloodBankName varchar(255) not null, Address varchar(255) not null, City varchar(255) not null, ContactNumber Bigint not null, UserID varchar(255) not null, Password Binary(32) not null )

alter user sqluser with default_schema=BBank
sp_help BloodDonorDonation

create table BBank.BloodDoner(BloodDonerId int primary key, FirstName varchar(255) not null, LastName varchar(255) not null, Address varchar(255) not null, City varchar(255) not null, MobileNo Bigint not null, BloodGroup varchar(255) constraint CHK_BloodGroup check(BloodGroup In('A +ve','B +ve','AB +ve','O +ve','A -ve','B -ve','AB -ve','O -ve')))

create table BBank.BloodDonationCamp(BloodDonationCampId int primary key, CampName varchar(255) not null, Address varchar(255) not null, City varchar(255) not null, BloodBankId int not null, CampStartDate datetime not null, CampEndDate datetime not null)

create table BBank.Hospital(HospitalId int primary key, HospitalName varchar(255) not null, Address varchar(255) not null, City varchar(255) not null, ContactNumber Bigint not null)

create table BBank.BloodDonerDonation(BloodDonationId int primary key, BloodDonerId int not null, BloodDonationDate datetime, NumberOfBottle int not null, Weight int not null, HBCount decimal not null)

create table BBank.BloodInventory(BloodInventoryId int primary key,  BloodGroup varchar(255) constraint CHK1_BloodGroup check(BloodGroup In('A +ve','B +ve','AB +ve','O +ve','A -ve','B -ve','AB -ve','O -ve')), NumberOfBottle int not null, BloodBankId int not null, ExpiryDate datetime not null)

alter table BloodDonationCamp add constraint FK_BloodBankId foreign key (BloodBankId) references BloodBank(BloodBankId) 

alter table BloodDonerDonation add constraint FK_BloodDonerId foreign key (BloodDonerId) references BloodDoner(BloodDonerId) 

alter table BloodInventory add constraint FK1_BloodBankId foreign key (BloodBankId) references BloodBank (BloodBankId)

alter table BBank.BloodInventory add HospitalId int not null  CONSTRAINT FK_HospitalId FOREIGN KEY (HospitalId) REFERENCES Hospital (HospitalId)


