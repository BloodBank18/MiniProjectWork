use Training_19Sep18_Pune

 alter proc BBank.ArrangeCamp
(
@BloodDonationCampId varchar(255),
@CampName varchar(255),
@Address varchar(255),
@City varchar(255),
@BloodBankId varchar(50),
@CampStartDate datetime,
@CampEndDate datetime
)
as
begin
	insert into BBank.BloodDonationCamp
	values(@BloodDonationCampId, @CampName, @Address, @City, @BloodBankId, @CampStartDate, @CampEndDate)
end

select * from BBank.Bloodbank

insert into BBank.BloodBank values (1, 'zxc', 'sad', 'sadsa', 34332321, 'admin', 7677)
insert into BBank.BloodBank values ('BB12345', 'zxc', 'sad', 'sadsa', 34332321, 'admin', 7677)

--create proc BBank.ViewCampDetails
--as
--begin
--	select * from BBank.BloodDonationCamp
--end

alter proc BBank.ModifyCamp
(
@BloodDonationCampId varchar(50),
@CampName varchar(255),
@Address varchar(255),
@City varchar(255),
@CampStartDate datetime,
@CampEndDate datetime
)
as
begin
	update BBank.BloodDonationCamp
	set CampName = @CampName, Address=@Address, City=@City, CampStartDate=@CampStartDate, CampEndDate=@CampEndDate
	where BloodDonationCampId = @BloodDonationCampId
end

alter proc BBank.DeleteCamp
(
@BloodDonationCampId varchar(255)
)
as
begin
	delete from BBank.BloodDonationCamp
	where BloodDonationCampId = @BloodDonationCampId
end

alter proc BBank.SearchCamp
(
@BloodDonationCampId varchar(255)
)
as
begin
	select * from BBank.BloodDonationCamp
	where BloodDonationCampId = @BloodDonationCampId
end

create proc VerifyBloodDonationCampId
(
@BloodDonationCampId varchar(50)
)
as
begin
	select count(*) from BBank.BloodDonationCamp Where BloodDonationCampId=@BloodDonationCampId
end