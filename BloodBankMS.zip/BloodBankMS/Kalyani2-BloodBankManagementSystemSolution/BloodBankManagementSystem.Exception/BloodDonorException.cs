﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace BloodBankManagementSystem.Exception
{
    [Serializable]
    public class BloodDonorException : ApplicationException
    {
        public BloodDonorException()
        {
        }

        public BloodDonorException(string message) : base(message)
        {
        }

        public BloodDonorException(string message, ApplicationException innerException) : base(message, innerException)
        {
        }

        protected BloodDonorException(SerializationInfo info, StreamingContext context) : base(info, context)
        {
        }
    }
}
