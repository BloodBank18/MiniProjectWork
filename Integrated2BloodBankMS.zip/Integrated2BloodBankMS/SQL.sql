use Training_19Sep18_Pune


alter proc BBank.uspVerifyBloodBankID
(
@bbID varchar(50)
)
as 
begin 
	select count(*) from BBank.BloodBank where BloodBankID=@bbID
end 



alter proc BBank.uspAddBloodBankDetails
(
@bbID varchar(50),
@bbName varchar(50),
@bbAddress varchar(50),
@bbCity varchar(50),
@bbContactNo bigint,
@bbUserID varchar(50),
@bbPassword binary(50)
)
as
begin
	insert into BBank.BloodBank values
(@bbID,
@bbName,
@bbAddress,
@bbCity,
@bbContactNo,
@bbUserID,
@bbPassword) 
end

alter proc BBank.uspAddBloodBankDetails2
(
@bbID varchar(50),
@bbName varchar(50),
@bbAddress varchar(50),
@bbCity varchar(50),
@bbContactNo bigint
)
as
begin
	insert into BBank.BloodBank
(BloodBankID,
BloodBankName,
Address,
City,
ContactNumber) values
(@bbID,
@bbName,
@bbAddress,
@bbCity,
@bbContactNo
) 
end

alter proc BBank.uspDisplayAllBloodBankDetails
as
begin
select BloodBankID,BloodBankName,Address,City,ContactNumber from BBank.BloodBank
end

alter proc BBank.uspUserLogin
(
@bbUserID varchar(50)
)
as
begin
	select Password from BBank.BloodBank
	where UserID=@bbUserID
end
select * from BBank.BloodBank
delete from BBank.BloodBank where BloodBankId='BB99999'
Insert into BBank.BloodBank values('BB99998','blood','shivaji chowk','pune',7788996654,'admin1','admin1')
alter proc BBank.uspSearchForDuplicateUser
(
@bbUserID varchar(50)
)
as 
begin
	select count(*) from BBank.BloodBank where UserID=@bbUserID
end

alter proc BBank.uspUpdateBloodBankDetails
(
@bbID varchar(50),
@bbName varchar(50),
@bbAddress varchar(50),
@bbCity varchar(50),
@bbContactNo bigint
)
as
begin
	update BBank.BloodBank set BloodBankName=@bbName,
	Address=@bbAddress,
	City=@bbCity,
	ContactNumber=@bbContactNo
	where
	BloodBankID=@bbID
end

create proc BBank.uspBloodBankID
as
begin
	select BloodBankID from BBank.BloodBank
end


create proc BBank.uspSearchBloodBankDetails
(
@bbID varchar(50)
)
as
begin
	select BloodBankName,
	Address,
	City,
	ContactNumber from BBank.BloodBank where BloodBankID=@bbID
end

create proc BBank.uspDeleteBloodBankDetails
(
@bbID varchar(50)
)
as 
begin
	delete from BBank.BloodBank where BloodBankID=@bbID
end

--=================================================================================

create proc BBank.uspVerifyHospitalID
(
@hID varchar(50)
)
as 
begin 
	select count(*) from BBank.Hospital where HospitalID=@hID
end 

create proc BBank.uspAddHospitalDetails
(
@hID varchar(50),
@hName varchar(50),
@hAddress varchar(50),
@hCity varchar(50),
@hContactNo bigint
)
as
begin
	insert into BBank.Hospital
(HospitalID,
HospitalName,
Address,
City,
ContactNumber) values
(@hID,
@hName,
@hAddress,
@hCity,
@hContactNo
) 
end

select * from BBank.Hospital

create proc BBank.uspDisplayAllHospitalDetails
as
begin
select HospitalID,HospitalName,Address,City,ContactNumber from BBank.Hospital
end


create proc BBank.uspHospitalID
as
begin
	select HospitalID from BBank.Hospital
end


alter proc BBank.uspSearchHospitalDetails
(
@hID varchar(50)
)
as
begin
	select HospitalName,
	Address,
	City,
	ContactNumber from BBank.Hospital where HospitalID=@hID
end

create proc BBank.uspUpdateHospitalDetails
(
@hID varchar(50),
@hName varchar(50),
@hAddress varchar(50),
@hCity varchar(50),
@hContactNo bigint
)
as
begin
	update BBank.Hospital set HospitalName=@hName,
	Address=@hAddress,
	City=@hCity,
	ContactNumber=@hContactNo
	where
	HospitalID=@hID
end

create proc BBank.uspDeleteHospitalDetails
(
@hID varchar(50)
)
as 
begin
	delete from BBank.Hospital where HospitalID=@hID
end

--===============================================================================
